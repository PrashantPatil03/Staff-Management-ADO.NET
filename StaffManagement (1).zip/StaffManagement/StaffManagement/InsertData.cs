﻿using StaffManagement.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagement
{
    public partial class InsertData : Form
    {
        public InsertData()
        {
            InitializeComponent();
        }

        private void InsertData_Load(object sender, EventArgs e)
        {

        }

        private void subbtn_Click(object sender, EventArgs e)
        {
            Staff st = new Staff();
            st.Sname = txtname.Text;
            st.Experience = Convert.ToInt32(txtex.Text);
            st.Cid = Convert.ToInt32(txtcid.Text);

            StaffLogic ob = new StaffLogic();
            string message = ob.AddData(st);
            MessageBox.Show(message);
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}

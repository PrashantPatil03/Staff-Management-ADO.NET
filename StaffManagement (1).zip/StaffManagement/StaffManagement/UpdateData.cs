﻿using StaffManagement.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagement
{
    
    public partial class UpdateData : Form
    {
        StaffLogic ob = new StaffLogic();
        public UpdateData()
        {
            InitializeComponent();
        }

        private void UpdateData_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = false;
            upbtn.Visible = false;
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtid.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                panel1.Visible = true;
                txtname.Text = res.Tables[0].Rows[0]["StaffName"].ToString();
                txtex.Text = res.Tables[0].Rows[0]["Experience"].ToString();
                txtcid.Text = res.Tables[0].Rows[0]["CID"].ToString();
                upbtn.Visible = true;
            }
            else
            {
                MessageBox.Show("record wrt id not found");
            }
        }

        private void upbtn_Click(object sender, EventArgs e)
        {
            Staff s = new Staff();
            s.Id = Convert.ToInt32(txtid.Value);
            s.Sname = txtname.Text;
            s.Experience = Convert.ToInt32(txtex.Text);
            s.Cid = Convert.ToInt32(txtcid.Text);
            string message = ob.UpdateData(s);
            MessageBox.Show(message);
            dataGridView1.DataSource = ob.getStaffDetails();
            dataGridView1.Visible = true;
        }
    }
}

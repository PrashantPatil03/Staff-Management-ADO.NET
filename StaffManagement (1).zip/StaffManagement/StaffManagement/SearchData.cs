﻿using StaffManagement.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagement
{
    public partial class SearchData : Form
    {
        public SearchData()
        {
            InitializeComponent();
        }

        private void SearchData_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnserach_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(TXTID.Value);
            StaffLogic ob = new StaffLogic();
            dataGridView1.DataSource = ob.GetSearchData(id).Tables[0];
            dataGridView1.Visible = true;
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}

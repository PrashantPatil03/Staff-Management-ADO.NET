﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffManagement.Model
{
    class Staff
    {
        public int Id { get; set; }
        public string Sname { get; set; }
        public int Experience { get; set; }
        public int Cid { get; set; }
        public override string ToString()
        {
            string str = " ";
            str += "StaffName=" + Sname;
            str += "Experience=" + Experience.ToString();
            str += "CID=" + Cid.ToString();
            return str;
        }
    }
}

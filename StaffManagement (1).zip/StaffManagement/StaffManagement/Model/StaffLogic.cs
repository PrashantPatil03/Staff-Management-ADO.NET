﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace StaffManagement.Model
{
    class StaffLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["staffdb"].ConnectionString;
        public List<Staff> getStaffDetails()
        {
            List<Staff> li = new List<Staff>();
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                string sql = "select *from Staff";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Staff s = new Staff();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.Sname = reader.GetValue(1).ToString();
                    s.Experience = Convert.ToInt32(reader.GetValue(2));
                    s.Cid = Convert.ToInt32(reader.GetValue(3));

                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return li;
        }
        public string AddData(Staff st)
        {
            string message = " ";
            string sql = "insert into Staff(StaffName,Experience,CID) values('";
            sql +=st.Sname+"'," + st.Experience + "," + st.Cid + ")";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                message = "the record inserted successfully:" + st.ToString();
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public DataSet GetSearchData(int id)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select *from Staff where Id=" + id.ToString();
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public string UpdateData(Staff s)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);
            
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("update_rec", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = s.Id;
                cmd.Parameters.Add("@StaffName", SqlDbType.VarChar,50).Value = s.Sname;
                cmd.Parameters.Add("@Experience", SqlDbType.Int).Value = s.Experience;
                cmd.Parameters.Add("@Cid", SqlDbType.Int).Value = s.Cid;
                cmd.ExecuteNonQuery();
                message = "the record inserted successfully:";
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();

            }
            return message;
        }
        public string DeleteData(int id)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("delete_rec", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                cmd.ExecuteNonQuery();
                message = "Data deleted sucessfully";

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
    }
}
